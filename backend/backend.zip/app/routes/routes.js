const express = require("express");
const router = express.Router();

const connection = require("../config/database");

const auth = require("../config/auth");
const UserController = require("../controller/userController");
const taskController = require("../controller/taskController");
const ContactController = require("../controller/contactusController");

//login
router.post("/user_login", UserController.userLogin);
router.post("/signup", UserController.Registration);
router.post("/getEmployeeFromTechnology", UserController.getEmployeeFromTechnology);
router.post("/detail/Employee", UserController.getEmployee);

//product
router.post("/add/task", taskController.AddTask);
router.post("/detail/TaskDetailFromEmployeeId", taskController.TaskDetailFromEmployeeId);
router.post("/update/taskStatus", taskController.updateTaskStatus);
router.post("/update/taskDetails", taskController.updateTaskDetails);

// router.post("/update/serviceStatus", ProductController.updateDetail);

router.post("/add/contactus", ContactController.ContactUs);


// attendance
// Mark attendance (Check-in)
router.post("/check-in", (req, res) => {
    const { employee_id } = req.body;
    const date = new Date().toISOString().split("T")[0];
    const checkInTime = new Date().toLocaleTimeString("en-US", { hour12: false });

    connection.query(
        "INSERT INTO attendance (employee_id, date, check_in, status) VALUES (?, ?, ?, 'Present') ON DUPLICATE KEY UPDATE check_in = ?, status = 'Present'",
        [employee_id, date, checkInTime, checkInTime],
        (err, result) => {
            if (err) return res.status(500).json({ error: err });
            res.json({ message: "Check-in recorded successfully" });
        }
    );
});

// Mark check-out
// router.post("/check-out", (req, res) => {
//     const { employee_id } = req.body;
//     const date = new Date().toISOString().split("T")[0];
//     const checkOutTime = new Date().toLocaleTimeString("en-US", { hour12: false });

//     connection.query(
//         "UPDATE attendance SET check_out = ? WHERE employee_id = ? AND date = ?",
//         [checkOutTime, employee_id, date],
//         (err, result) => {
//             if (err) return res.status(500).json({ error: err });
//             res.json({ message: "Check-out recorded successfully" });
//         }
//     );
// });

// router.post("/check-out", (req, res) => {
//     const { employee_id } = req.body;
//     const date = new Date().toISOString().split("T")[0];
//     const checkOutTime = new Date().toLocaleTimeString("en-US", { hour12: false });

//     // Check if an attendance record exists
//     connection.query(
//         "SELECT * FROM attendance WHERE employee_id = ? AND date = ?",
//         [employee_id, date],
//         (err, results) => {
//             if (err) {
//                 console.error("Database Error:", err);
//                 return res.status(500).json({ error: err });
//             }

//             if (results.length === 0) {
//                 console.warn("Check-out attempt failed: No check-in record found.");
//                 return res.status(400).json({ message: "No check-in record found for this employee today" });
//             }

//             console.log("Existing Attendance Record:", results[0]); // Debugging

//             // Now update the check_out time
//             connection.query(
//                 "UPDATE attendance SET check_out = ? WHERE employee_id = ? AND date = ?",
//                 [checkOutTime, employee_id, date],
//                 (err, result) => {
//                     if (err) {
//                         console.error("Check-out Update Error:", err);
//                         return res.status(500).json({ error: err });
//                     }

//                     if (result.affectedRows === 0) {
//                         console.warn("Check-out update failed: No matching record found.");
//                         return res.status(400).json({ message: "Check-out failed, no matching record found." });
//                     }

//                     console.log("Check-out recorded successfully:", checkOutTime);
//                     res.json({ message: "Check-out recorded successfully" });
//                 }
//             );
//         }
//     );
// });

// Mark check-out


router.post("/check-out", (req, res) => {
    const { employee_id } = req.body;
    const date = new Date().toISOString().split("T")[0];  
    const checkOutTime = new Date().toLocaleTimeString("en-US", { hour12: false });

    // Check if an attendance record exists
    connection.query(
        "SELECT * FROM attendance WHERE employee_id = ? AND date = ?",
        [employee_id, date],
        (err, results) => {
            if (err) return res.status(500).json({ error: err });

            if (results.length === 0) {
                return res.status(400).json({ message: "No check-in record found for this employee today" });
            }

            console.log("Existing Attendance Record:", results[0]);  // Debug log

            // Now update the check_out time
            connection.query(
                "UPDATE attendance SET check_out = ? WHERE employee_id = ? AND date = ?",
                [checkOutTime, employee_id, date],
                (err, result) => {
                    if (err) return res.status(500).json({ error: err });

                    if (result.affectedRows === 0) {
                        return res.status(400).json({ message: "Check-out failed, no matching record found." });
                    }

                    res.json({ message: "Check-out recorded successfully" });
                }
            );
        }
    );
});



// router.post("/check-out", (req, res) => {
//     const { employee_id } = req.body;
//     const date = new Date().toISOString().split("T")[0];  
//     const checkOutTime = new Date().toLocaleTimeString("en-US", { hour12: false });

//     // Check if an attendance record exists
//     connection.query(
//         "SELECT * FROM attendance WHERE employee_id = ? AND date = ?",
//         [employee_id, date],
//         (err, results) => {
//             if (err) return res.status(500).json({ error: err });

//             if (results.length === 0) {
//                 return res.status(400).json({ message: "No check-in record found for this employee today" });
//             }

//             console.log("Existing Attendance Record:", results[0]);  // Debug log

//             // Now update the check_out time
//             connection.query(
//                 "UPDATE attendance SET check_out = ? WHERE employee_id = ? AND date = ?",
//                 [checkOutTime, employee_id, date],
//                 (err, result) => {
//                     if (err) return res.status(500).json({ error: err });

//                     if (result.affectedRows === 0) {
//                         return res.status(400).json({ message: "Check-out failed, no matching record found." });
//                     }

//                     res.json({ message: "Check-out recorded successfully" });
//                 }
//             );
//         }
//     );
// });


// Get attendance records
router.get("/:employee_id", (req, res) => {
    const { employee_id } = req.params;
    connection.query(
        "SELECT * FROM attendance WHERE employee_id = ?",
        [employee_id],
        (err, results) => {
            if (err) return res.status(500).json({ error: err });
            res.json(results);
        }
    );
});

module.exports = router;


// const express = require("express");
// const router = express.Router();
// const mongoose = require("mongoose");

// const UserController = require("../controller/userController");
// const TaskController = require("../controller/taskController");
// const ContactController = require("../controller/contactusController");

// // const Attendance = require("../models/Attendance");
// const Attendance = require("../Models/empModel")
// // const Employee = require('../Models/empModel');
// const Employee = require('../Models/empModel')

// // Login & User Routes
// router.post("/user_login", UserController.userLogin);
// router.post("/signup", UserController.Registration);
// router.post("/getEmployeeFromTechnology", UserController.getEmployeeFromTechnology);
// router.post("/detail/Employee", UserController.getEmployee);

// // Task Routes
// router.post("/add/task", TaskController.AddTask);
// router.post("/detail/TaskDetailFromEmployeeId", TaskController.TaskDetailFromEmployeeId);
// router.post("/update/taskStatus", TaskController.updateTaskStatus);

// // Contact Us Route
// router.post("/add/contactus", ContactController.ContactUs);

// // =============================
// // ATTENDANCE MANAGEMENT
// // =============================

// // ✅ Mark attendance (Check-in)
// router.post("/check-in", async (req, res) => {
//     try {
//         const { employee_id } = req.body;
//         const date = new Date().toISOString().split("T")[0];
//         const checkInTime = new Date().toLocaleTimeString("en-US", { hour12: false });

//         let attendance = await Attendance.findOne({ employee_id, date });

//         if (attendance) {
//             // If already exists, update check-in
//             attendance.check_in = checkInTime;
//             attendance.status = "Present";
//         } else {
//             // Otherwise, create a new attendance record
//             attendance = new Attendance({
//                 employee_id,
//                 date,
//                 check_in: checkInTime,
//                 status: "Present"
//             });
//         }

//         await attendance.save();
//         res.json({ message: "Check-in recorded successfully" });

//     } catch (error) {
//         res.status(500).json({ error: error.message });
//     }
// });

// // ✅ Mark check-out
// router.post("/check-out", async (req, res) => {
//     try {
//         const { employee_id } = req.body;
//         const date = new Date().toISOString().split("T")[0];
//         const checkOutTime = new Date().toLocaleTimeString("en-US", { hour12: false });

//         let attendance = await Attendance.findOne({ employee_id, date });

//         if (!attendance) {
//             return res.status(400).json({ message: "No check-in record found for this employee today" });
//         }

//         attendance.check_out = checkOutTime;
//         await attendance.save();

//         res.json({ message: "Check-out recorded successfully" });

//     } catch (error) {
//         res.status(500).json({ error: error.message });
//     }
// });

// // ✅ Get attendance records for an employee
// router.get("/:employee_id", async (req, res) => {
//     try {
//         const { employee_id } = req.params;
//         const records = await Attendance.find({ employee_id });
//         res.json(records);
//     } catch (error) {
//         res.status(500).json({ error: error.message });
//     }
// });

// // controller/userController.js
// // const Employee = require("../models/empModel");

// exports.userLogin = async (req, res) => {
//     try {
//         const { Email, Password } = req.body;

//         if (!Email || !Password) {
//             return res.status(400).json({ message: "Email and Password are required" });
//         }

//         // const result = await Employee.findOne({ Email });
//         const result = await Employee.findOne({ Email: { $regex: new RegExp(`^${Email}$`, 'i') } });
//         if (!result || result.Password !== Password) {
//             return res.status(401).json({ message: "Invalid Email or Password" });
//         }

//         res.json({
//             success: true,
//             result: {
//                 id: result._id,
//                 Email: result.Email,
//                 admin: result.admin || false,
//                 Position: result.Position || "",
//                 Technology: result.Technology || "",
//             }
//         });
//     } catch (error) {
//         console.error("Login error:", error);
//         res.status(500).json({ message: "Internal Server Error" });
//     }
// };

// module.exports = router;

