exports = FOLDER_NAME = {
  USER_PROFILES: 1,
};

exports = FILE_EXTENSION = {
  USER: ".jpg",
  EMAI: ".jpg",
  HOLIDAYS: ".jpg",
  WEB: ".jpg",
  LOGO: ".jpg",
};
