// const mongoose = require("mongoose");

// // Employee Registration Schema
// const EmployeeSchema = new mongoose.Schema({
//     FirstName: { type: String, required: true },
//     LastName: { type: String, required: true },
//     Email: { type: String, required: true, unique: true },
//     Password: { type: String, required: true },
//     Number: { type: String, required: true },
//     Technology: { type: String, default: "" },
//     Position: { type: String, required: true },
//     Address: { type: String, required: true },
//     Salary: { type: String, required: true },
//     BankAccountNumber: { type: String, required: true },
//     PFNumber: { type: String, required: true },
//     JoiningDate: { type: String, required: true },
//     CIFNumber: { type: String, required: true },
//     Photo: { type: String, required: true },
//     admin: { type: Boolean, default: false },
//     created_at: { type: Date, default: Date.now }
// });

// // const Employee = mongoose.models.Employee || mongoose.model("Employee", EmployeeSchema);
// module.exports = mongoose.models.Employee || mongoose.model('Employee', EmployeeSchema);
// // const Employee = mongoose.model("Employee", EmployeeSchema);
// // module.exports = Employee;

// // Contact Us Schema
// const ContactUsSchema = new mongoose.Schema({
//     name: { type: String, required: true },
//     email: { type: String, required: true },
//     subject: { type: String, required: true },
//     message: { type: String, required: true },
//     Date: { type: Date, default: Date.now }
// });

// // const ContactUs = mongoose.model("ContactUs", ContactUsSchema);
// module.exports = mongoose.models.ContactUs || mongoose.model('ContactUs', ContactUsSchema);

// // Task Schema
// const TaskSchema = new mongoose.Schema({
//     TaskName: { type: String, required: true },
//     Technology: { type: String, required: true },
//     Description: { type: String, required: true },
//     FromEmployee: { type: mongoose.Schema.Types.ObjectId, ref: "Employee", required: true },
//     ToEmployee: { type: mongoose.Schema.Types.ObjectId, ref: "Employee", required: true },
//     status: { type: String, enum: ["To do", "In Progress", "Completed"], default: "To do" },
//     FromEmployeeName: { type: String, required: true },
//     ToEmployeeName: { type: String, required: true },
//     EndDate: { type: String, required: true }
// });

// // const Task = mongoose.model("Task", TaskSchema);
// module.exports = mongoose.models.Task || mongoose.model('Task', TaskSchema);

// // Attendance Schema
// const AttendanceSchema = new mongoose.Schema({
//     employee_id: { type: mongoose.Schema.Types.ObjectId, ref: "Employee", required: true },
//     date: { type: Date, required: true },
//     check_in: { type: String, default: null },
//     check_out: { type: String, default: null },
//     status: { type: String, enum: ["Present", "Absent", "Late", "Leave"], default: "Absent" },
//     created_at: { type: Date, default: Date.now },
//     updated_at: { type: Date, default: Date.now }
// });

// // const Attendance = mongoose.model("Attendance", AttendanceSchema);
// module.exports = mongoose.models.Attendance || mongoose.model('Attendance', AttendanceSchema);


// // module.exports = { Employee, Task, Attendance };
