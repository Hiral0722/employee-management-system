const tables = {
  employeeregistration: "employeeregistration",
  task: "task",
  servicebooking: "servicebooking",
  contactus:"contectus"
};

module.exports = tables;
