const mysql = require("mysql2");

const connection = mysql.createConnection({
    host: "localhost",
    user: "root",
    // password: "YES",
    database: "employy",
});



connection.connect(err => {
    if (err) {
        console.error("Database connection failed:", err);
    } else {
        console.log("Connected to MySQL database.");
    }
});


module.exports = connection;


// const mongoose = require('mongoose')

// const connectdb = (con) =>{
//     return mongoose.connect(con).then(() =>{
//         console.log("connection successfull");
//     }).catch((err) =>{
//         console.log("this is database error",err);
//     })
// }

// module.exports = connectdb


// const mongoose = require("mongoose");

// mongoose.connect("mongodb+srv://patelhiral22:Hiralemp2207@clusteremp.1njyya1.mongodb.net/?retryWrites=true&w=majority", {
//     useNewUrlParser: true,
//     useUnifiedTopology: true
// })
// .then(() => console.log("MongoDB connected successfully!"))
// .catch(err => console.error("MongoDB connection error:", err));

// module.exports = mongoose;
