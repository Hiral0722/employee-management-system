// const mongoose = require("./config/database");  // Import MongoDB connection
// const { Employee } = require("./Models/empModel"); // Import Employee Model correctly

// const employees = [ {
//     FirstName: "Admin",
//     LastName: "Admin",
//     Email: "admin@admin.com",
//     Password: "123456",
//     Number: "7458961023",
//     Technology: "Management",
//     Position: "admin",
//     Address: "Head Office",  // ✅ Provide a valid address
//     Salary: 0,
//     BankAccountNumber: "0000000000",  // ✅ Provide a default account number
//     PFNumber: "000000",  // ✅ Provide a default PF number
//     JoiningDate: new Date("2023-04-14"),
//     CIFNumber: "ADMIN123",  // ✅ Provide a valid CIF number
//     Photo: "user_profiles/Admin.jpg",
//     admin: true,
//     created_at: new Date("2023-04-14T07:09:49Z")
// }
// ];

// // Function to insert data
// const seedDatabase = async () => {
//     try {
//         await Employee.insertMany(employees);
//         console.log("✅ Employees data inserted successfully!");
//         process.exit();
//     } catch (error) {
//         console.error("❌ Error inserting data:", error);
//         process.exit(1);
//     }
// };

// seedDatabase();
