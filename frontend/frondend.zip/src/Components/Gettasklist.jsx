import React from "react";

const Gettasklist = () => {
  return (
    <>
      HI
    </>
  );
};

export default Gettasklist;
